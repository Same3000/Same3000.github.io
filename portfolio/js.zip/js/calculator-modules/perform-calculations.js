export function calculate(firstOperand, secondOperand, operator) 

calculate(firstOperand, secondOperand, operator)